package aula2;

public class Calculadora {

    Double numA;
    Double numB;

    Double somar(){

        return numA + numB;
    }

    Double subtrair(){

        return numA - numB;
    }

    Double multiplicar(){

        return numA * numB;


    }

    Double dividir(){

        return numA / numB;


    }
}
